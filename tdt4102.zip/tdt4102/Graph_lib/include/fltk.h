// Documetation can be found at http://tdt4102.pages.stud.idi.ntnu.no/graph_lib/
/** @file */
#pragma once

#include "FL/Fl.H"
#include "FL/Fl_Double_Window.H"
#include "FL/Fl_Button.H"
#include "FL/Fl_Input.H"
#include "FL/Fl_Output.H"
#include "FL/Fl_Multiline_Output.H"
#include "FL/Fl_Choice.H"
#include <cstdlib>       // for exit(0)
#include "FL/fl_draw.H"
#include "FL/Enumerations.H"

#include "FL/Fl_JPEG_Image.H"
#include "FL/Fl_GIF_Image.H"
