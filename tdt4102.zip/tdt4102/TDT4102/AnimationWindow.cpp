#include "AnimationWindow.h"
#include <Graph.h>
#include <thread>
#include <chrono>

void TDT4102::AnimationWindow::draw() {
    drawHasOccurred = true;
    if(!keepPreviousFrame || !hasClearedWindowAtLeastOnce) {
        Fl_Double_Window::draw();
        hasClearedWindowAtLeastOnce = true;
    }
    drawWindowContents();
    drawer.draw();
    if(!isIdling) {
        drawer.clear();
    }
}

void TDT4102::AnimationWindow::next_frame() {
    while(!should_close() && !drawHasOccurred) {
        Fl::wait(0);
    }
    drawHasOccurred = false;
    input.updateWindowPosition({this->x(), this->y()});
}

bool TDT4102::AnimationWindow::should_close() {
    // Quit if FLTK has detected an exit request, or if the user has closed the window.
    return Fl::program_should_quit() || !this->shown();
}

void TDT4102::AnimationWindow::wait_for_close() {
    isIdling = true;
    Fl::run();
    
    // Handles window close requests
    Fl::wait(0);
}

void TDT4102::AnimationWindow::wait_for(double timeSeconds) {
    std::this_thread::sleep_for(std::chrono::microseconds(int(1000000.0*timeSeconds)));
}

bool TDT4102::AnimationWindow::is_idling() {
    return isIdling;
}

void TDT4102::AnimationWindow::keep_previous_frame(bool enabled) {
    this->keepPreviousFrame = enabled;
}

void TDT4102::internal::windowTimedUpdateHandler(void *windowInCallbackUserdata) {
    TDT4102::AnimationWindow *window = (TDT4102::AnimationWindow*) windowInCallbackUserdata;
    window->redraw();
    if(window->is_idling()) {
        Fl::repeat_timeout(TDT4102::internal::idleSecondsPerFrame, TDT4102::internal::windowTimedUpdateHandler, windowInCallbackUserdata);
    } else {
        Fl::repeat_timeout(TDT4102::internal::activeSecondsPerFrame, TDT4102::internal::windowTimedUpdateHandler, windowInCallbackUserdata);
    }
}

void TDT4102::AnimationWindow::draw_circle(Graph_lib::Point centre, int radius, Graph_lib::Color color) {
    drawer.drawCircle(centre, radius, color);
}

void TDT4102::AnimationWindow::draw_rectangle(Graph_lib::Point topLeftPoint, int width, int height, Graph_lib::Color color) {
    drawer.drawRectangle(topLeftPoint, width, height, color);
}

void TDT4102::AnimationWindow::draw_image(Graph_lib::Point topLeftPoint, Graph_lib::Image & image) {
    drawer.drawImage(topLeftPoint, image);
}

void TDT4102::AnimationWindow::draw_text(Graph_lib::Point bottomLeftPoint, string textToShow, Graph_lib::Color color, unsigned int fontSize, Graph_lib::Font font) {
    drawer.drawText(bottomLeftPoint, textToShow, color, fontSize, font);
}

void TDT4102::AnimationWindow::draw_line(Graph_lib::Point start, Graph_lib::Point end, Graph_lib::Color color) {
    drawer.drawLine(start, end, color);
}

void TDT4102::AnimationWindow::draw_triangle(Graph_lib::Point vertex0, Graph_lib::Point vertex1,
                                             Graph_lib::Point vertex2,Graph_lib::Color color) {
    drawer.drawTriangle(vertex0, vertex1, vertex2, color);
}

void TDT4102::AnimationWindow::draw_quad(Graph_lib::Point vertex0, Graph_lib::Point vertex1, Graph_lib::Point vertex2,
                                         Graph_lib::Point vertex3, Graph_lib::Color color) {
    drawer.drawQuad(vertex0, vertex1, vertex2, vertex3, color);
}

void TDT4102::AnimationWindow::draw_arc(Graph_lib::Point center, int width, int height, int start_degree, int end_degree, Graph_lib::Color color) {
    drawer.drawArc(center, width, height, start_degree, end_degree, color);
}

bool TDT4102::AnimationWindow::is_key_down(KeyboardKey key) {
    return input.is_key_down(key);
}

Graph_lib::Point TDT4102::AnimationWindow::get_mouse_coordinates() {
    return input.get_mouse_coordinates();
}

