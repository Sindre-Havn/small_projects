#pragma once

#include <Point.h>
#include "KeyboardKey.h"

namespace TDT4102 {
    class InputHandler {
        friend class AnimationWindow;
        int windowX = 0;
        int windowY = 0;
    public:
        bool is_key_down(KeyboardKey key);
        Graph_lib::Point get_mouse_coordinates();

    protected:
        // Called by AnimationWindow once per frame
        void updateWindowPosition(Graph_lib::Point location);
    };
}