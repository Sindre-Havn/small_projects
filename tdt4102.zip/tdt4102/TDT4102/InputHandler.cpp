#include <FL/Fl.H>
#include "InputHandler.h"

bool TDT4102::InputHandler::is_key_down(KeyboardKey key) {
    return Fl::get_key(int(key));
}

Graph_lib::Point TDT4102::InputHandler::get_mouse_coordinates() {
    int mouseX;
    int mouseY;
    Fl::get_mouse(mouseX, mouseY);
    return Graph_lib::Point {mouseX - this->windowX, mouseY - this->windowY};
}

void TDT4102::InputHandler::updateWindowPosition(Graph_lib::Point location) {
    this->windowX = location.x;
    this->windowY = location.y;
}