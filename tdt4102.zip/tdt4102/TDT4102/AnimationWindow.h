#pragma once

#include "Window.h"
#include "ShapeDrawQueue.h"
#include "InputHandler.h"
#include <FL/Fl_Double_Window.H>

namespace TDT4102 {
    namespace internal {
        // These variables set the rate at which this window should draw frames.

        static const double activeFramesPerSecond = 60.0;
        static const double activeSecondsPerFrame = 1.0 / activeFramesPerSecond;

        static const double idleFramesPerSecond = 15.0;
        static const double idleSecondsPerFrame = 1.0 / idleFramesPerSecond;

        void windowTimedUpdateHandler(void *window);
    }

    // This class inherits from FLTK's double window
    // "double" refers to the fact that it uses double buffering, or more specifically, the window maintains two
    // versions of the pixels inside of it. One of these it is transmitting to the display, the other one it's
    // drawing the next image to show you. Using single buffering for graphical animations tends to result in
    // flickering, which is obviously not desirable.
    class AnimationWindow : public Fl_Double_Window {

    private:
        // In order to work around the way FLTK wants windows to be drawn, we queue up all shapes you tell this window to draw.
        TDT4102::ShapeDrawQueue drawer;

        // Handles all requests for input.
        InputHandler input;

        // If set to true, new shapes will be drawn on top of the old ones. Can create some neat effects.
        // However, note that GUI elements such as buttons will not draw themselves correctly if you use this.
        bool keepPreviousFrame = false;

        // Some variables that are necessary for the window to behave correctly
        bool isIdling = false;
        bool drawHasOccurred = false;
        bool hasClearedWindowAtLeastOnce = false;

    public:
        explicit AnimationWindow(int x = 50, int y = 50, int width = 1024, int height = 768, const string& title = "Animation Window") : Fl_Double_Window(x, y, width, height, title.c_str()) {
            // The window draws at a framerate of 60 frames per second. This is done by creating a timer which periodically checks if
            // you have finished drawing yet, and if so, tells FLTK to draw the window.
            // This line sets the first of these timers
            Fl::add_timeout(TDT4102::internal::activeSecondsPerFrame, TDT4102::internal::windowTimedUpdateHandler, (void*)this);

            // Allow the window to be resized
            resizable(this);

            // Automatically show the window when it is created
            show();
        }

        // Imperative graphics works a bit differently compared to what is shown in the book
        // you should instead use one of the draw_xxx functions listed below :)
        void attach(Graph_lib::Shape& s) = delete;

        // When you have finished drawing a frame, call this function to display it (usually at the end of your main while loop)
        void next_frame();

        // Returns true if someone has clicked the close button of the window
        bool should_close();

        // See the comment above talking about the keepPreviousFrame variable :)
        void keep_previous_frame(bool enabled);

        // Run the application until someone closes the window.
        // Using this function makes sure GUI elements such as buttons are interactive and are drawn.
        void wait_for_close();

        // Mostly meant for internal use. Returns true if the wait_for_close() function has been called
        bool is_idling();

        void wait_for(double timeSeconds);


        // These functions should hopefully be rather self-explanatory.
        // They allow you to draw a variety of different shapes.
        void draw_circle(Graph_lib::Point centre, int radius, Graph_lib::Color color = Graph_lib::Color::dark_blue);
        void draw_rectangle(Graph_lib::Point topLeftPoint, int width, int height, Graph_lib::Color color = Graph_lib::Color::dark_green);
        void draw_image(Graph_lib::Point topLeftPoint, Graph_lib::Image &image);
        void draw_text(Graph_lib::Point bottomLeftPoint, std::string textToShow, Graph_lib::Color color = Graph_lib::Color::black, unsigned int fontSize = 20, Graph_lib::Font font = Graph_lib::Font::helvetica);
        void draw_line(Graph_lib::Point start, Graph_lib::Point end, Graph_lib::Color color = Graph_lib::Color::black);
        void draw_triangle(Graph_lib::Point vertex0, Graph_lib::Point vertex1, Graph_lib::Point vertex2, Graph_lib::Color color = Graph_lib::Color::yellow);
        void draw_quad(Graph_lib::Point vertex0, Graph_lib::Point vertex1, Graph_lib::Point vertex2, Graph_lib::Point vertex3, Graph_lib::Color color = Graph_lib::Color::cyan);
        void draw_arc(Graph_lib::Point center, int width, int height, int start_degree, int end_degree, Graph_lib::Color color = Graph_lib::Color::black);


        // And these functions are for handling input
        bool is_key_down(KeyboardKey key);
        Graph_lib::Point get_mouse_coordinates();

    protected:
        // This window will not work correctly if draw() is overridden.
        void draw() final;
        virtual void drawWindowContents() {
            // Do nothing; meant to be overridden
        }
    };


}

