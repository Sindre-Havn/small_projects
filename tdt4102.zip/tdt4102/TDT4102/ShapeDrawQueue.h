#pragma once

#include <Graph.h>

namespace TDT4102 {
    // This class queues up draw commands in order to be able to draw them later.
    // The reason for this is that FLTK wants to decide when it redraws the window.
    // We therefore queue up draw commands, and subsequently give FLTK a hint that maaaaybe it's time to redraw the window.

    class ShapeDrawQueue {
    private:
        enum class ShapeType {
            RECTANGLE, CIRCLE, IMAGE, LINE, TEXT, TRIANGLE, QUAD, ARC
        };

        // Graph_lib's shapes cannot be used in a vector because their copy constructors have been deleted
        // Which avoids mistakes when they are stored interchangeably.
        // However, that means we need to create a separate means to store them here.
        struct ShapeToDraw {
            Graph_lib::Point vertex0;
            Graph_lib::Point vertex1;
            Graph_lib::Point vertex2;
            Graph_lib::Point vertex3;
            int width = 0;
            int height = 0;
            Graph_lib::Color color = Graph_lib::Color::white;
            Graph_lib::Font font = Graph_lib::Font::helvetica;
            ShapeType type;
            Graph_lib::Image* image;
            std::string text;
        };

        std::vector<ShapeToDraw> drawQueue;
    public:
        ShapeDrawQueue() {}
        void draw();
        void clear();

        void drawCircle(Graph_lib::Point centre, int radius, Graph_lib::Color color = Graph_lib::Color::red);
        void drawRectangle(Graph_lib::Point topLeftCorner, int width, int height, Graph_lib::Color color = Graph_lib::Color::dark_green);
        void drawImage(Graph_lib::Point topLeftCorner, Graph_lib::Image &image);
        void drawText(Graph_lib::Point bottomLeftCorner, string &textToShow, Graph_lib::Color color, unsigned int fontSize, Graph_lib::Font font);
        void drawLine(Graph_lib::Point start, Graph_lib::Point end, Graph_lib::Color color);
        void drawTriangle(Graph_lib::Point vertex0, Graph_lib::Point vertex1, Graph_lib::Point vertex2, Graph_lib::Color color);
        void drawQuad(Graph_lib::Point vertex0, Graph_lib::Point vertex1, Graph_lib::Point vertex2, Graph_lib::Point vertex3, Graph_lib::Color color);
        void drawArc(Graph_lib::Point center, int width, int height, int start_degree, int end_degree, Graph_lib::Color color);
    };
}
