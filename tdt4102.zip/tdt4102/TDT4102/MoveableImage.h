#pragma once

#include <Graph.h>

// This class exists solely as a means to be able to move an instance of Graph_lib::Image
// without causing it to draw itself.

class MoveableImage : Graph_lib::Image {
public:
    void moveTo(Graph_lib::Point point);
};