#include <FL/Fl_Box.H>
#include "ShapeDrawQueue.h"
#include "MoveableImage.h"

// You may notice that I'm abusing fields in ShapeToDraw for things that their name suggests is not their intended purpose.
// For example, I use the width and height fields to denote the end X and Y coordinate of a line.
// This is a case of "do as I say, not as I do"
// Please don't do this in practice

void TDT4102::ShapeDrawQueue::drawCircle(Graph_lib::Point centre, int radius, Graph_lib::Color color) {
    ShapeToDraw shape;
    shape.vertex0 = centre;
    shape.width = radius;
    shape.color = color;
    shape.type = ShapeType::CIRCLE;
    drawQueue.push_back(shape);
}

void TDT4102::ShapeDrawQueue::drawRectangle(Graph_lib::Point topLeftCorner, int width, int height, Graph_lib::Color color) {
    ShapeToDraw shape;
    shape.vertex0 = topLeftCorner;
    shape.width = width;
    shape.height = height;
    shape.color = color;
    shape.type = ShapeType::RECTANGLE;
    drawQueue.push_back(shape);
}

void TDT4102::ShapeDrawQueue::drawImage(Graph_lib::Point topLeftCorner, Graph_lib::Image &image) {
    ShapeToDraw shape;
    shape.vertex0 = topLeftCorner;
    shape.image = &image;
    shape.type = ShapeType::IMAGE;
    drawQueue.push_back(shape);
}

void TDT4102::ShapeDrawQueue::drawText(Graph_lib::Point bottomLeftCorner, string &textToShow, Graph_lib::Color color, unsigned int fontSize, Graph_lib::Font font) {
    ShapeToDraw shape;
    shape.vertex0 = bottomLeftCorner;
    shape.text = textToShow;
    shape.color = color;
    shape.height = int(fontSize);
    shape.font = font;
    shape.type = ShapeType::TEXT;
    drawQueue.push_back(shape);
}

void TDT4102::ShapeDrawQueue::drawLine(Graph_lib::Point start, Graph_lib::Point end, Graph_lib::Color color) {
    ShapeToDraw shape;
    shape.vertex0 = start;
    shape.vertex1 = end;
    shape.color = color;
    shape.type = ShapeType::LINE;
    drawQueue.push_back(shape);
}

void TDT4102::ShapeDrawQueue::drawTriangle(Graph_lib::Point vertex0, Graph_lib::Point vertex1, Graph_lib::Point vertex2,
                                           Graph_lib::Color color) {
    ShapeToDraw shape;
    shape.vertex0 = vertex0;
    shape.vertex1 = vertex1;
    shape.vertex2 = vertex2;
    shape.color = color;
    shape.type = ShapeType::TRIANGLE;
    drawQueue.push_back(shape);
}

void TDT4102::ShapeDrawQueue::drawQuad(Graph_lib::Point vertex0, Graph_lib::Point vertex1, Graph_lib::Point vertex2,
                                       Graph_lib::Point vertex3, Graph_lib::Color color) {
    ShapeToDraw shape;
    shape.vertex0 = vertex0;
    shape.vertex1 = vertex1;
    shape.vertex2 = vertex2;
    shape.vertex3 = vertex3;
    shape.color = color;
    shape.type = ShapeType::QUAD;
    drawQueue.push_back(shape);
}

void TDT4102::ShapeDrawQueue::drawArc(Graph_lib::Point center, int width, int height, int start_degree, int end_degree, Graph_lib::Color color) {
    ShapeToDraw shape;
    shape.vertex0 = center;
    shape.vertex1 = {start_degree, end_degree};
    shape.width = width;
    shape.height = height;
    shape.color = color;
    shape.type = ShapeType::ARC;
    drawQueue.push_back(shape);
}


void TDT4102::ShapeDrawQueue::draw() {
    for(const ShapeToDraw& shape : drawQueue) {
        if(shape.type == ShapeType::RECTANGLE) {
            Graph_lib::Rectangle rectangle(shape.vertex0, shape.width, shape.height);
            rectangle.set_fill_color(shape.color);
            rectangle.draw_lines();
        } else if(shape.type == ShapeType::CIRCLE) {
            Graph_lib::Circle circle(shape.vertex0, shape.width);
            circle.set_fill_color(shape.color);
            circle.draw_lines();
        } else if(shape.type == ShapeType::IMAGE) {
            // Feast thine eyes upon this abomination of a way to force an image to a particular location.
            // Graph_lib::Image has some problems:
            // - It does not let you draw it in a specific location
            // - It has made both its size and image references private
            // - Specifying a location to draw it requires knowing its dimensions
            // - Moving an image by a delta amount also draws it
            // This is what we call "terrible design".
            // we therefore have to jump through a backdoor instead.
            MoveableImage* tempImage = (MoveableImage*) shape.image;
            tempImage->moveTo(shape.vertex0);
            shape.image->draw_lines();
        } else if(shape.type == ShapeType::TEXT) {
            Graph_lib::Text textShape(shape.vertex0, shape.text);
            textShape.set_color(shape.color);
            textShape.set_font(shape.font);
            textShape.set_font_size(shape.height);
            textShape.draw();
        } else if(shape.type == ShapeType::LINE) {
            Graph_lib::Line lineShape(shape.vertex0, shape.vertex1);
            lineShape.set_color(shape.color);
            lineShape.draw();
        } else if(shape.type == ShapeType::TRIANGLE) {
            Graph_lib::Polygon triangleShape;
            triangleShape.add(shape.vertex0);
            triangleShape.add(shape.vertex1);
            triangleShape.add(shape.vertex2);
            triangleShape.set_fill_color(shape.color);
            triangleShape.draw_lines();
        } else if(shape.type == ShapeType::QUAD) {
            Graph_lib::Polygon quadShape;
            quadShape.add(shape.vertex0);
            quadShape.add(shape.vertex1);
            quadShape.add(shape.vertex2);
            quadShape.add(shape.vertex3);
            quadShape.set_fill_color(shape.color);
            quadShape.draw_lines();
        } else if(shape.type == ShapeType::ARC) {
            Graph_lib::Arc arcShape(shape.vertex0, shape.width, shape.height, shape.vertex1.x, shape.vertex1.y);
            arcShape.set_color(shape.color);
            arcShape.draw_lines();
        }
    }
}

void TDT4102::ShapeDrawQueue::clear() {
    // Note: this clears the queue, but does not deallocate their memory.
    drawQueue.clear();
}
















