#include "MoveableImage.h"

void MoveableImage::moveTo(Graph_lib::Point point) {
    this->set_point(0, point);
}
